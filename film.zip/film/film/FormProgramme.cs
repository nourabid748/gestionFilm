﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace film
{
    public partial class FormProgramme : Form
    {
        public FormProgramme()
        {
            InitializeComponent();
        }

        private void programmeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.programmeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.filmDataSet);

        }

        private void FormProgramme_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'filmDataSet.SalleDeCinema'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.salleDeCinemaTableAdapter.Fill(this.filmDataSet.SalleDeCinema);
            // TODO: cette ligne de code charge les données dans la table 'filmDataSet.Film'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.filmTableAdapter.Fill(this.filmDataSet.Film);
            // TODO: cette ligne de code charge les données dans la table 'filmDataSet.Programme'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.programmeTableAdapter.Fill(this.filmDataSet.Programme);

        }

        private void ajouter_Click(object sender, EventArgs e)
        {
            try
            {

                filmEntities f = new filmEntities();

                // Récupérer l'ID du film sélectionné
                long selectedFilmId = (long)filmComboBox.SelectedValue;

                // Récupérer l'ID de la salle de cinéma sélectionnée
                long selectedSalleId = (long)salleDeCinemaComboBox.SelectedValue;

                // Récupérer l'objet Film correspondant à l'ID
                Film selectedFilm = f.Film.Find(selectedFilmId);

                // Récupérer l'objet SalleDeCinema correspondant à l'ID
                SalleDeCinema selectedSalle = f.SalleDeCinema.Find(selectedSalleId);

                // Convertir l'ID en long
                long id = long.Parse(idTextBox.Text);

                // Créer un nouvel objet Programme avec les valeurs récupérées
                Programme p = new Programme(
                    id,
                    int.Parse(capaciteTextBox.Text),
                    dateDebutDateTimePicker.Value,
                    heureDebutDateTimePicker.Value,
                    selectedFilmId,
                    selectedSalleId,
                    selectedFilm,
                    selectedSalle);

                // Ajouter le nouveau programme à votre source de données
                f.Programme.Add(p);
                f.SaveChanges();
                this.programmeTableAdapter.Fill(this.filmDataSet.Programme);


            }
            catch (Exception ex) { 
                MessageBox.Show("Erreur lors de l'ajout du programme : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void modifier_Click(object sender, EventArgs e)
        {
            try
            {
                filmEntities f = new filmEntities();

                // Récupérer l'ID du programme à modifier
                long programmeId = long.Parse(idTextBox.Text);
                Programme programmeAModifier = f.Programme.FirstOrDefault(p => p.id == programmeId);

                if (programmeAModifier != null)
                {
                    // Mettre à jour tous les champs du programme avec les nouvelles valeurs
                    programmeAModifier.capacite = int.Parse(capaciteTextBox.Text);
                    programmeAModifier.dateDebut = dateDebutDateTimePicker.Value;
                    programmeAModifier.heureDebut = heureDebutDateTimePicker.Value;

                    // Récupérer les nouvelles valeurs des ComboBox pour le film et la salle de cinéma
                    long selectedFilmId = (long)filmComboBox.SelectedValue;
                    long selectedSalleId = (long)salleDeCinemaComboBox.SelectedValue;

                    // Mettre à jour les références aux objets Film et SalleDeCinema
                    programmeAModifier.idFilm = selectedFilmId;
                    programmeAModifier.idSalle = selectedSalleId;

                    // Sauvegarder les modifications dans la base de données
                    f.SaveChanges();

                    // Actualiser les données affichées dans le formulaire
                    this.programmeTableAdapter.Fill(this.filmDataSet.Programme);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de modification du programme : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void supprimer_Click(object sender, EventArgs e)
        {
            try
            {
                filmEntities f = new filmEntities();

                // Récupérer l'ID du programme sélectionné
                long programmeId = long.Parse(idTextBox.Text);

                // Récupérer le programme sélectionné
                Programme programmeASupprimer = f.Programme.FirstOrDefault(p => p.id == programmeId);

                if (programmeASupprimer != null)
                {
                    // Supprimer le programme
                    f.Programme.Remove(programmeASupprimer);
                    f.SaveChanges();

                    // Actualiser les données affichées dans le formulaire
                    this.programmeTableAdapter.Fill(this.filmDataSet.Programme);

                    // Vider les champs après la suppression
                    ViderChamps();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de suppression du programme : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ViderChamps()
        {
            idTextBox.Text = "";
            capaciteTextBox.Text = "";

        }

        private void nouveau_Click(object sender, EventArgs e)
        {
            ViderChamps();
        }

        private void filmComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void salleDeCinemaComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateDebutDateTimePicker_ValueChanged(object sender, EventArgs e)
        {

        }

        private void heureDebutDateTimePicker_ValueChanged(object sender, EventArgs e)
        {

        }

        private void retour_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void programme_Click(object sender, EventArgs e)
        {

            FormProgramme form1 = new FormProgramme();
            form1.Show();
            this.Hide();
        }
    }
}

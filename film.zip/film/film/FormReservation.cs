﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace film
{
    public partial class FormReservation : Form
    {
        public FormReservation()
        {
            InitializeComponent();
        }

        private void reservationBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.reservationBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.filmDataSet);

        }

        private void FormReservation_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'filmDataSet.Programme'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.programmeTableAdapter.Fill(this.filmDataSet.Programme);
            // TODO: cette ligne de code charge les données dans la table 'filmDataSet.Client'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.clientTableAdapter.Fill(this.filmDataSet.Client);
            // TODO: cette ligne de code charge les données dans la table 'filmDataSet.Reservation'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.reservationTableAdapter.Fill(this.filmDataSet.Reservation);

        }

        private void emailComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void idTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void nombreDePlacesTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ajouter_Click(object sender, EventArgs e)
        {
            try
            {
                filmEntities f = new filmEntities();

                // Récupérer l'ID du client sélectionné
                long selectedClientId = (long)clientComboBox.SelectedValue;

                // Récupérer l'ID du programme sélectionné
                long selectedProgrammeId = (long)programmeComboBox.SelectedValue;

                // Créer une nouvelle réservation avec les valeurs saisies par l'utilisateur
                Reservation nouvelleReservation = new Reservation
                {
                    nombreDePlaces = int.Parse(nombreDePlacesTextBox.Text),
                    idClient = selectedClientId,
                    idProgramme = selectedProgrammeId
                };

                // Ajouter la nouvelle réservation à la base de données
                f.Reservation.Add(nouvelleReservation);
                f.SaveChanges();

                // Actualiser l'affichage des réservations
                this.reservationTableAdapter.Fill(this.filmDataSet.Reservation);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout du programme : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void modifier_Click(object sender, EventArgs e)
        {
            try
            {

                filmEntities f = new filmEntities();

                // Récupérer l'ID de la réservation à modifier
                long reservationId = long.Parse(idTextBox.Text);
                Reservation reservationAModifier = f.Reservation.FirstOrDefault(r => r.id == reservationId);

                if (reservationAModifier != null)
                {
                    // Mettre à jour tous les champs de la réservation avec les nouvelles valeurs
                    reservationAModifier.nombreDePlaces = int.Parse(nombreDePlacesTextBox.Text);

                    // Récupérer les nouvelles valeurs des ComboBox pour le client et le programme
                    long selectedClientId = (long)clientComboBox.SelectedValue;
                    long selectedProgrammeId = (long)programmeComboBox.SelectedValue;

                    // Mettre à jour les références aux objets Client et Programme
                    reservationAModifier.idClient = selectedClientId;
                    reservationAModifier.idProgramme = selectedProgrammeId;

                    // Sauvegarder les modifications dans la base de données
                    f.SaveChanges();

                    // Actualiser les données affichées dans le formulaire
                    this.reservationTableAdapter.Fill(this.filmDataSet.Reservation);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de modificaton du reservation : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void supprimer_Click(object sender, EventArgs e)
        {
            try
            {
                filmEntities f = new filmEntities();

                // Récupérer l'ID de la réservation sélectionnée
                long reservationId = long.Parse(idTextBox.Text);

                // Récupérer la réservation sélectionnée
                Reservation reservationASupprimer = f.Reservation.FirstOrDefault(r => r.id == reservationId);

                if (reservationASupprimer != null)
                {
                    // Supprimer la réservation
                    f.Reservation.Remove(reservationASupprimer);
                    f.SaveChanges();

                    // Actualiser les données affichées dans le formulaire
                    this.reservationTableAdapter.Fill(this.filmDataSet.Reservation);

                    // Vider les champs après la suppression
                    ViderChamps();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout du reservation : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ViderChamps()
        {
            idTextBox.Text = "";

        }
        private void nouveau_Click(object sender, EventArgs e)
        {
            ViderChamps();
        }

        private void programmeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void clientComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void retour_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}

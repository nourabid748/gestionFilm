﻿namespace film
{
    partial class FormProgramme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idLabel;
            System.Windows.Forms.Label capaciteLabel;
            System.Windows.Forms.Label dateDebutLabel;
            System.Windows.Forms.Label heureDebutLabel;
            System.Windows.Forms.Label idFilmLabel;
            System.Windows.Forms.Label idSalleLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormProgramme));
            this.filmDataSet = new film.filmDataSet();
            this.programmeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.programmeTableAdapter = new film.filmDataSetTableAdapters.ProgrammeTableAdapter();
            this.tableAdapterManager = new film.filmDataSetTableAdapters.TableAdapterManager();
            this.filmTableAdapter = new film.filmDataSetTableAdapters.FilmTableAdapter();
            this.salleDeCinemaTableAdapter = new film.filmDataSetTableAdapters.SalleDeCinemaTableAdapter();
            this.programmeBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.programmeBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.programmeDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idTextBox = new System.Windows.Forms.TextBox();
            this.capaciteTextBox = new System.Windows.Forms.TextBox();
            this.dateDebutDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.heureDebutDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.filmBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.filmComboBox = new System.Windows.Forms.ComboBox();
            this.salleDeCinemaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.salleDeCinemaComboBox = new System.Windows.Forms.ComboBox();
            this.ajouter = new System.Windows.Forms.Button();
            this.modifier = new System.Windows.Forms.Button();
            this.supprimer = new System.Windows.Forms.Button();
            this.nouveau = new System.Windows.Forms.Button();
            this.retour = new System.Windows.Forms.Button();
            idLabel = new System.Windows.Forms.Label();
            capaciteLabel = new System.Windows.Forms.Label();
            dateDebutLabel = new System.Windows.Forms.Label();
            heureDebutLabel = new System.Windows.Forms.Label();
            idFilmLabel = new System.Windows.Forms.Label();
            idSalleLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.filmDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.programmeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.programmeBindingNavigator)).BeginInit();
            this.programmeBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.programmeDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.filmBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salleDeCinemaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // idLabel
            // 
            idLabel.AutoSize = true;
            idLabel.Location = new System.Drawing.Point(16, 64);
            idLabel.Name = "idLabel";
            idLabel.Size = new System.Drawing.Size(21, 16);
            idLabel.TabIndex = 2;
            idLabel.Text = "id:";
            // 
            // capaciteLabel
            // 
            capaciteLabel.AutoSize = true;
            capaciteLabel.Location = new System.Drawing.Point(16, 92);
            capaciteLabel.Name = "capaciteLabel";
            capaciteLabel.Size = new System.Drawing.Size(62, 16);
            capaciteLabel.TabIndex = 4;
            capaciteLabel.Text = "capacite:";
            // 
            // dateDebutLabel
            // 
            dateDebutLabel.AutoSize = true;
            dateDebutLabel.Location = new System.Drawing.Point(16, 121);
            dateDebutLabel.Name = "dateDebutLabel";
            dateDebutLabel.Size = new System.Drawing.Size(76, 16);
            dateDebutLabel.TabIndex = 6;
            dateDebutLabel.Text = "date Debut:";
            // 
            // heureDebutLabel
            // 
            heureDebutLabel.AutoSize = true;
            heureDebutLabel.Location = new System.Drawing.Point(16, 149);
            heureDebutLabel.Name = "heureDebutLabel";
            heureDebutLabel.Size = new System.Drawing.Size(83, 16);
            heureDebutLabel.TabIndex = 8;
            heureDebutLabel.Text = "heure Debut:";
            // 
            // idFilmLabel
            // 
            idFilmLabel.AutoSize = true;
            idFilmLabel.Location = new System.Drawing.Point(16, 189);
            idFilmLabel.Name = "idFilmLabel";
            idFilmLabel.Size = new System.Drawing.Size(35, 16);
            idFilmLabel.TabIndex = 10;
            idFilmLabel.Text = "Film:";
            // 
            // idSalleLabel
            // 
            idSalleLabel.AutoSize = true;
            idSalleLabel.Location = new System.Drawing.Point(16, 227);
            idSalleLabel.Name = "idSalleLabel";
            idSalleLabel.Size = new System.Drawing.Size(41, 16);
            idSalleLabel.TabIndex = 12;
            idSalleLabel.Text = "Salle:";
            // 
            // filmDataSet
            // 
            this.filmDataSet.DataSetName = "filmDataSet";
            this.filmDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // programmeBindingSource
            // 
            this.programmeBindingSource.DataMember = "Programme";
            this.programmeBindingSource.DataSource = this.filmDataSet;
            // 
            // programmeTableAdapter
            // 
            this.programmeTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.FilmTableAdapter = this.filmTableAdapter;
            this.tableAdapterManager.ProgrammeTableAdapter = this.programmeTableAdapter;
            this.tableAdapterManager.RealisateurTableAdapter = null;
            this.tableAdapterManager.ReservationTableAdapter = null;
            this.tableAdapterManager.SalleDeCinemaTableAdapter = this.salleDeCinemaTableAdapter;
            this.tableAdapterManager.TypeDeSalleTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = film.filmDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // filmTableAdapter
            // 
            this.filmTableAdapter.ClearBeforeFill = true;
            // 
            // salleDeCinemaTableAdapter
            // 
            this.salleDeCinemaTableAdapter.ClearBeforeFill = true;
            // 
            // programmeBindingNavigator
            // 
            this.programmeBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.programmeBindingNavigator.BindingSource = this.programmeBindingSource;
            this.programmeBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.programmeBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.programmeBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.programmeBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.programmeBindingNavigatorSaveItem});
            this.programmeBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.programmeBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.programmeBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.programmeBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.programmeBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.programmeBindingNavigator.Name = "programmeBindingNavigator";
            this.programmeBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.programmeBindingNavigator.Size = new System.Drawing.Size(906, 27);
            this.programmeBindingNavigator.TabIndex = 0;
            this.programmeBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorAddNewItem.Text = "Ajouter nouveau";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(48, 24);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Nombre total d\'éléments";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorDeleteItem.Text = "Supprimer";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Placer en premier";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Déplacer vers le haut";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Position actuelle";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Déplacer vers le bas";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Placer en dernier";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // programmeBindingNavigatorSaveItem
            // 
            this.programmeBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.programmeBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("programmeBindingNavigatorSaveItem.Image")));
            this.programmeBindingNavigatorSaveItem.Name = "programmeBindingNavigatorSaveItem";
            this.programmeBindingNavigatorSaveItem.Size = new System.Drawing.Size(29, 24);
            this.programmeBindingNavigatorSaveItem.Text = "Enregistrer les données";
            this.programmeBindingNavigatorSaveItem.Click += new System.EventHandler(this.programmeBindingNavigatorSaveItem_Click);
            // 
            // programmeDataGridView
            // 
            this.programmeDataGridView.AutoGenerateColumns = false;
            this.programmeDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.programmeDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.programmeDataGridView.DataSource = this.programmeBindingSource;
            this.programmeDataGridView.Location = new System.Drawing.Point(12, 262);
            this.programmeDataGridView.Name = "programmeDataGridView";
            this.programmeDataGridView.RowHeadersWidth = 51;
            this.programmeDataGridView.RowTemplate.Height = 24;
            this.programmeDataGridView.Size = new System.Drawing.Size(804, 184);
            this.programmeDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn1.HeaderText = "id";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "capacite";
            this.dataGridViewTextBoxColumn2.HeaderText = "capacite";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "dateDebut";
            this.dataGridViewTextBoxColumn3.HeaderText = "dateDebut";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "heureDebut";
            this.dataGridViewTextBoxColumn4.HeaderText = "heureDebut";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "idFilm";
            this.dataGridViewTextBoxColumn5.HeaderText = "idFilm";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "idSalle";
            this.dataGridViewTextBoxColumn6.HeaderText = "idSalle";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // idTextBox
            // 
            this.idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.programmeBindingSource, "id", true));
            this.idTextBox.Location = new System.Drawing.Point(105, 61);
            this.idTextBox.Name = "idTextBox";
            this.idTextBox.Size = new System.Drawing.Size(200, 22);
            this.idTextBox.TabIndex = 3;
            // 
            // capaciteTextBox
            // 
            this.capaciteTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.programmeBindingSource, "capacite", true));
            this.capaciteTextBox.Location = new System.Drawing.Point(105, 89);
            this.capaciteTextBox.Name = "capaciteTextBox";
            this.capaciteTextBox.Size = new System.Drawing.Size(200, 22);
            this.capaciteTextBox.TabIndex = 5;
            // 
            // dateDebutDateTimePicker
            // 
            this.dateDebutDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.programmeBindingSource, "dateDebut", true));
            this.dateDebutDateTimePicker.Location = new System.Drawing.Point(105, 117);
            this.dateDebutDateTimePicker.Name = "dateDebutDateTimePicker";
            this.dateDebutDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.dateDebutDateTimePicker.TabIndex = 7;
            this.dateDebutDateTimePicker.ValueChanged += new System.EventHandler(this.dateDebutDateTimePicker_ValueChanged);
            // 
            // heureDebutDateTimePicker
            // 
            this.heureDebutDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.programmeBindingSource, "heureDebut", true));
            this.heureDebutDateTimePicker.Location = new System.Drawing.Point(105, 145);
            this.heureDebutDateTimePicker.Name = "heureDebutDateTimePicker";
            this.heureDebutDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.heureDebutDateTimePicker.TabIndex = 9;
            this.heureDebutDateTimePicker.ValueChanged += new System.EventHandler(this.heureDebutDateTimePicker_ValueChanged);
            // 
            // filmBindingSource
            // 
            this.filmBindingSource.DataMember = "Film";
            this.filmBindingSource.DataSource = this.filmDataSet;
            // 
            // filmComboBox
            // 
            this.filmComboBox.DataSource = this.filmBindingSource;
            this.filmComboBox.DisplayMember = "titre";
            this.filmComboBox.FormattingEnabled = true;
            this.filmComboBox.Location = new System.Drawing.Point(105, 186);
            this.filmComboBox.Name = "filmComboBox";
            this.filmComboBox.Size = new System.Drawing.Size(300, 24);
            this.filmComboBox.TabIndex = 14;
            this.filmComboBox.ValueMember = "id";
            this.filmComboBox.SelectedIndexChanged += new System.EventHandler(this.filmComboBox_SelectedIndexChanged);
            // 
            // salleDeCinemaBindingSource
            // 
            this.salleDeCinemaBindingSource.DataMember = "SalleDeCinema";
            this.salleDeCinemaBindingSource.DataSource = this.filmDataSet;
            // 
            // salleDeCinemaComboBox
            // 
            this.salleDeCinemaComboBox.DataSource = this.salleDeCinemaBindingSource;
            this.salleDeCinemaComboBox.DisplayMember = "nom";
            this.salleDeCinemaComboBox.FormattingEnabled = true;
            this.salleDeCinemaComboBox.Location = new System.Drawing.Point(105, 227);
            this.salleDeCinemaComboBox.Name = "salleDeCinemaComboBox";
            this.salleDeCinemaComboBox.Size = new System.Drawing.Size(300, 24);
            this.salleDeCinemaComboBox.TabIndex = 15;
            this.salleDeCinemaComboBox.ValueMember = "id";
            this.salleDeCinemaComboBox.SelectedIndexChanged += new System.EventHandler(this.salleDeCinemaComboBox_SelectedIndexChanged);
            // 
            // ajouter
            // 
            this.ajouter.Location = new System.Drawing.Point(535, 64);
            this.ajouter.Name = "ajouter";
            this.ajouter.Size = new System.Drawing.Size(75, 23);
            this.ajouter.TabIndex = 16;
            this.ajouter.Text = "ajouter";
            this.ajouter.UseVisualStyleBackColor = true;
            this.ajouter.Click += new System.EventHandler(this.ajouter_Click);
            // 
            // modifier
            // 
            this.modifier.Location = new System.Drawing.Point(535, 104);
            this.modifier.Name = "modifier";
            this.modifier.Size = new System.Drawing.Size(75, 23);
            this.modifier.TabIndex = 17;
            this.modifier.Text = "modifier";
            this.modifier.UseVisualStyleBackColor = true;
            this.modifier.Click += new System.EventHandler(this.modifier_Click);
            // 
            // supprimer
            // 
            this.supprimer.Location = new System.Drawing.Point(535, 149);
            this.supprimer.Name = "supprimer";
            this.supprimer.Size = new System.Drawing.Size(75, 23);
            this.supprimer.TabIndex = 18;
            this.supprimer.Text = "supprimer";
            this.supprimer.UseVisualStyleBackColor = true;
            this.supprimer.Click += new System.EventHandler(this.supprimer_Click);
            // 
            // nouveau
            // 
            this.nouveau.Location = new System.Drawing.Point(535, 189);
            this.nouveau.Name = "nouveau";
            this.nouveau.Size = new System.Drawing.Size(75, 23);
            this.nouveau.TabIndex = 19;
            this.nouveau.Text = "nouveau";
            this.nouveau.UseVisualStyleBackColor = true;
            this.nouveau.Click += new System.EventHandler(this.nouveau_Click);
            // 
            // retour
            // 
            this.retour.Location = new System.Drawing.Point(12, 30);
            this.retour.Name = "retour";
            this.retour.Size = new System.Drawing.Size(39, 25);
            this.retour.TabIndex = 20;
            this.retour.Text = "<--";
            this.retour.UseVisualStyleBackColor = true;
            this.retour.Click += new System.EventHandler(this.retour_Click);
            // 
            // FormProgramme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(906, 458);
            this.Controls.Add(this.retour);
            this.Controls.Add(this.nouveau);
            this.Controls.Add(this.supprimer);
            this.Controls.Add(this.modifier);
            this.Controls.Add(this.ajouter);
            this.Controls.Add(this.salleDeCinemaComboBox);
            this.Controls.Add(this.filmComboBox);
            this.Controls.Add(idLabel);
            this.Controls.Add(this.idTextBox);
            this.Controls.Add(capaciteLabel);
            this.Controls.Add(this.capaciteTextBox);
            this.Controls.Add(dateDebutLabel);
            this.Controls.Add(this.dateDebutDateTimePicker);
            this.Controls.Add(heureDebutLabel);
            this.Controls.Add(this.heureDebutDateTimePicker);
            this.Controls.Add(idFilmLabel);
            this.Controls.Add(idSalleLabel);
            this.Controls.Add(this.programmeDataGridView);
            this.Controls.Add(this.programmeBindingNavigator);
            this.Name = "FormProgramme";
            this.Text = "FormProgramme";
            this.Load += new System.EventHandler(this.FormProgramme_Load);
            ((System.ComponentModel.ISupportInitialize)(this.filmDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.programmeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.programmeBindingNavigator)).EndInit();
            this.programmeBindingNavigator.ResumeLayout(false);
            this.programmeBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.programmeDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.filmBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salleDeCinemaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private filmDataSet filmDataSet;
        private System.Windows.Forms.BindingSource programmeBindingSource;
        private filmDataSetTableAdapters.ProgrammeTableAdapter programmeTableAdapter;
        private filmDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator programmeBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton programmeBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView programmeDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private filmDataSetTableAdapters.FilmTableAdapter filmTableAdapter;
        private System.Windows.Forms.TextBox idTextBox;
        private System.Windows.Forms.TextBox capaciteTextBox;
        private System.Windows.Forms.DateTimePicker dateDebutDateTimePicker;
        private System.Windows.Forms.DateTimePicker heureDebutDateTimePicker;
        private System.Windows.Forms.BindingSource filmBindingSource;
        private filmDataSetTableAdapters.SalleDeCinemaTableAdapter salleDeCinemaTableAdapter;
        private System.Windows.Forms.ComboBox filmComboBox;
        private System.Windows.Forms.BindingSource salleDeCinemaBindingSource;
        private System.Windows.Forms.ComboBox salleDeCinemaComboBox;
        private System.Windows.Forms.Button ajouter;
        private System.Windows.Forms.Button modifier;
        private System.Windows.Forms.Button supprimer;
        private System.Windows.Forms.Button nouveau;
        private System.Windows.Forms.Button retour;
    }
}
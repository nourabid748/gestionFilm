﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace film
{
    public partial class FormClient : Form
    {
        public FormClient()
        {
            InitializeComponent();
        }

        private void clientBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.clientBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.filmDataSet);

        }

        private void FormClient_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'filmDataSet.Client'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.clientTableAdapter.Fill(this.filmDataSet.Client);

        }

        private void ajouter_Click(object sender, EventArgs e)
        {
            try
            {
                filmEntities f = new filmEntities();
                Client client = new Client(int.Parse(idTextBox.Text), nomTextBox.Text, prenomTextBox.Text, adrTextBox.Text, emailTextBox.Text);
                f.Client.Add(client);
                f.SaveChanges();
                this.clientTableAdapter.Fill(this.filmDataSet.Client);

            }
            catch (Exception ex) { MessageBox.Show("Erreur lors de l'ajout du client : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
        private void modifier_Click(object sender, EventArgs e)
        {
            try
            {
                filmEntities f = new filmEntities();

                // Récupérer le client à modifier
                int clientId = int.Parse(idTextBox.Text);
                Client clientAModifier = f.Client.FirstOrDefault(c => c.id == clientId);

                if (clientAModifier != null)
                {
                    // Mettre à jour tous les champs du client avec les nouvelles valeurs
                    clientAModifier.nom = nomTextBox.Text;
                    clientAModifier.prenom = prenomTextBox.Text;
                    clientAModifier.adr = adrTextBox.Text;
                    clientAModifier.email = emailTextBox.Text;

                    // Sauvegarder les modifications dans la base de données
                    f.SaveChanges();

                    // Actualiser les données affichées dans le formulaire
                    this.clientTableAdapter.Fill(this.filmDataSet.Client);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de modification du client : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void supprimer_Click(object sender, EventArgs e)
        {
            try
            {
                filmEntities f = new filmEntities();

                // Récupérer l'ID du client sélectionné
                int clientId = int.Parse(idTextBox.Text);

                // Récupérer le client sélectionné
                Client clientASupprimer = f.Client.FirstOrDefault(c => c.id == clientId);

                if (clientASupprimer != null)
                {
                    // Vérifier s'il y a des réservations associées à ce client
                    bool reservationsExist = f.Reservation.Any(r => r.idClient == clientId);

                    if (reservationsExist)
                    {
                        // Afficher un message à l'utilisateur pour l'avertir que le client a des réservations associées
                        MessageBox.Show("Ce client a des réservations associées et ne peut pas être supprimé.", "Suppression impossible", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        // Supprimer le client uniquement s'il n'y a pas de réservations associées
                        f.Client.Remove(clientASupprimer);
                        f.SaveChanges();

                        // Actualiser les données affichées dans le formulaire
                        this.clientTableAdapter.Fill(this.filmDataSet.Client);

                        // Vider les champs après la suppression
                        ViderChamps();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de suppression du client : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ViderChamps()
        {

            idTextBox.Text = "";  // Vider le champ de texte de l'identifiant
            nomTextBox.Text = ""; // Vider le champ de texte du nom
            prenomTextBox.Text = ""; // Vider le champ de texte du prénom
            adrTextBox.Text = ""; // Vider le champ de texte de la rue
            emailTextBox.Text = ""; // Vider le champ de texte de la ville
            
        }
        private void nouveau_Click(object sender, EventArgs e)
        {
            ViderChamps();

        }

        private void reservation_Click(object sender, EventArgs e)
        {
            FormReservation formReservation = new FormReservation();
            formReservation.Show();
            this.Hide();
        }

        private void retour_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}

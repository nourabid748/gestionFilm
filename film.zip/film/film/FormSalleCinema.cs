﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace film
{
    public partial class FormSalleCinema : Form
    {
        public FormSalleCinema()
        {
            InitializeComponent();
        }

        private void salleDeCinemaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.salleDeCinemaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.filmDataSet);

        }

        private void FormSalleCinema_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'filmDataSet.TypeDeSalle'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.typeDeSalleTableAdapter.Fill(this.filmDataSet.TypeDeSalle);
            // TODO: cette ligne de code charge les données dans la table 'filmDataSet.SalleDeCinema'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.salleDeCinemaTableAdapter.Fill(this.filmDataSet.SalleDeCinema);

        }
        private void ViderChamps()
        {
            idTextBox.Text = "";
            nomTextBox.Text = "";
            adresseTextBox.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ViderChamps();
        }

        private void idTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void nomTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void adresseTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void typeDeSalleComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ajouter_Click(object sender, EventArgs e)
        {
            try {
                filmEntities f = new filmEntities();
                SalleDeCinema salle = new SalleDeCinema()
                {
                    nom = nomTextBox.Text,
                    adresse = adresseTextBox.Text,
                    idType = (long)typeDeSalleComboBox.SelectedValue // Suppose que la valeur de l'ID du type de salle est stockée dans la ComboBox
                };
                f.SalleDeCinema.Add(salle);
                f.SaveChanges();
                this.salleDeCinemaTableAdapter.Fill(this.filmDataSet.SalleDeCinema);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout du salle : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void modifier_Click(object sender, EventArgs e)
        {
            try
            {
                filmEntities f = new filmEntities();

                // Récupérer la salle à modifier
                int salleId = int.Parse(idTextBox.Text);
                SalleDeCinema salleAModifier = f.SalleDeCinema.FirstOrDefault(sal => sal.id == salleId);

                if (salleAModifier != null)
                {
                    // Mettre à jour tous les champs de la salle avec les nouvelles valeurs
                    salleAModifier.nom = nomTextBox.Text;
                    salleAModifier.adresse = adresseTextBox.Text;
                    salleAModifier.idType = (long)typeDeSalleComboBox.SelectedValue; // Suppose que la valeur de l'ID du type de salle est stockée dans la ComboBox

                    // Sauvegarder les modifications dans la base de données
                    f.SaveChanges();

                    // Actualiser les données affichées dans le formulaire
                    this.salleDeCinemaTableAdapter.Fill(this.filmDataSet.SalleDeCinema);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de modification de salle : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void supprimer_Click(object sender, EventArgs e)
        {
            try
            {
                filmEntities f = new filmEntities();

                // Récupérer l'ID de la salle sélectionnée
                int salleId = int.Parse(idTextBox.Text);

                // Récupérer la salle sélectionnée
                SalleDeCinema salleASupprimer = f.SalleDeCinema.FirstOrDefault(sal => sal.id == salleId);

                if (salleASupprimer != null)
                {
                    // Supprimer la salle
                    f.SalleDeCinema.Remove(salleASupprimer);
                    f.SaveChanges();

                    // Actualiser les données affichées dans le formulaire
                    this.salleDeCinemaTableAdapter.Fill(this.filmDataSet.SalleDeCinema);

                    // Vider les champs après la suppression
                    ViderChamps();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de suppression de salle : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void salleDeCinemaDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void retour_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}

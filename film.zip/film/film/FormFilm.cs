﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace film
{
    public partial class FormFilm : Form
    {
        public FormFilm()
        {
            InitializeComponent();
        }

        private void filmBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.filmBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.filmDataSet);

        }

        private void FormFilm_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'filmDataSet.Realisateur'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.realisateurTableAdapter.Fill(this.filmDataSet.Realisateur);
            // TODO: cette ligne de code charge les données dans la table 'filmDataSet.Film'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.filmTableAdapter.Fill(this.filmDataSet.Film);

        }

        private void ajouter_Click(object sender, EventArgs e)
        {
            try
            {
                filmEntities f = new filmEntities();
                Film film = new Film()
                {
                    titre = titreTextBox.Text,
                    description = descriptionTextBox.Text,
                    idRealisateur = (long)realisateurComboBox.SelectedValue // Suppose que la valeur de l'ID du réalisateur est stockée dans la ComboBox
                };
                f.Film.Add(film);
                f.SaveChanges();
                this.filmTableAdapter.Fill(this.filmDataSet.Film);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout du film : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void modifier_Click(object sender, EventArgs e)
        {
            try
            {
                filmEntities f = new filmEntities();

                // Récupérer le film à modifier
                int filmId = int.Parse(idTextBox.Text);
                Film filmAModifier = f.Film.FirstOrDefault(fil => fil.id == filmId);

                if (filmAModifier != null)
                {
                    // Mettre à jour tous les champs du film avec les nouvelles valeurs
                    filmAModifier.titre = titreTextBox.Text;
                    filmAModifier.description = descriptionTextBox.Text;
                    filmAModifier.idRealisateur = (long)realisateurComboBox.SelectedValue; // Suppose que la valeur de l'ID du réalisateur est stockée dans la ComboBox

                    // Sauvegarder les modifications dans la base de données
                    f.SaveChanges();

                    // Actualiser les données affichées dans le formulaire
                    this.filmTableAdapter.Fill(this.filmDataSet.Film);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de modification de film : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void supprimer_Click(object sender, EventArgs e)
        {
            try
            {
                filmEntities f = new filmEntities();

                // Récupérer l'ID du film sélectionné
                int filmId = int.Parse(idTextBox.Text);

                // Récupérer le film sélectionné
                Film filmASupprimer = f.Film.FirstOrDefault(fil => fil.id == filmId);

                if (filmASupprimer != null)
                {
                    // Supprimer le film
                    f.Film.Remove(filmASupprimer);
                    f.SaveChanges();

                    // Actualiser les données affichées dans le formulaire
                    this.filmTableAdapter.Fill(this.filmDataSet.Film);

                    // Vider les champs après la suppression
                    ViderChamps();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout du programme : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ViderChamps()
        {
            idTextBox.Text = "";
            titreTextBox.Text = "";
            descriptionTextBox.Text = "";
        }

        private void nouveau_Click(object sender, EventArgs e)
        {
            ViderChamps();
        }

        private void idTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void titreTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void descriptionTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void realisateurComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void filmDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void retour_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}

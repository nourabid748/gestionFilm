﻿namespace film
{
    partial class FormSalleCinema
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idLabel;
            System.Windows.Forms.Label nomLabel;
            System.Windows.Forms.Label adresseLabel;
            System.Windows.Forms.Label typeLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSalleCinema));
            this.filmDataSet = new film.filmDataSet();
            this.salleDeCinemaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.salleDeCinemaTableAdapter = new film.filmDataSetTableAdapters.SalleDeCinemaTableAdapter();
            this.tableAdapterManager = new film.filmDataSetTableAdapters.TableAdapterManager();
            this.typeDeSalleTableAdapter = new film.filmDataSetTableAdapters.TypeDeSalleTableAdapter();
            this.salleDeCinemaBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.salleDeCinemaBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.salleDeCinemaDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idTextBox = new System.Windows.Forms.TextBox();
            this.nomTextBox = new System.Windows.Forms.TextBox();
            this.adresseTextBox = new System.Windows.Forms.TextBox();
            this.ajouter = new System.Windows.Forms.Button();
            this.modifier = new System.Windows.Forms.Button();
            this.supprimer = new System.Windows.Forms.Button();
            this.nouveau = new System.Windows.Forms.Button();
            this.typeDeSalleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.typeDeSalleBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.typeDeSalleComboBox = new System.Windows.Forms.ComboBox();
            this.retour = new System.Windows.Forms.Button();
            idLabel = new System.Windows.Forms.Label();
            nomLabel = new System.Windows.Forms.Label();
            adresseLabel = new System.Windows.Forms.Label();
            typeLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.filmDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salleDeCinemaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salleDeCinemaBindingNavigator)).BeginInit();
            this.salleDeCinemaBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.salleDeCinemaDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeDeSalleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeDeSalleBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // idLabel
            // 
            idLabel.AutoSize = true;
            idLabel.Location = new System.Drawing.Point(24, 116);
            idLabel.Name = "idLabel";
            idLabel.Size = new System.Drawing.Size(21, 16);
            idLabel.TabIndex = 2;
            idLabel.Text = "id:";
            // 
            // nomLabel
            // 
            nomLabel.AutoSize = true;
            nomLabel.Location = new System.Drawing.Point(24, 144);
            nomLabel.Name = "nomLabel";
            nomLabel.Size = new System.Drawing.Size(36, 16);
            nomLabel.TabIndex = 4;
            nomLabel.Text = "nom:";
            // 
            // adresseLabel
            // 
            adresseLabel.AutoSize = true;
            adresseLabel.Location = new System.Drawing.Point(24, 172);
            adresseLabel.Name = "adresseLabel";
            adresseLabel.Size = new System.Drawing.Size(60, 16);
            adresseLabel.TabIndex = 6;
            adresseLabel.Text = "adresse:";
            // 
            // typeLabel
            // 
            typeLabel.AutoSize = true;
            typeLabel.Location = new System.Drawing.Point(24, 220);
            typeLabel.Name = "typeLabel";
            typeLabel.Size = new System.Drawing.Size(36, 16);
            typeLabel.TabIndex = 14;
            typeLabel.Text = "type:";
            // 
            // filmDataSet
            // 
            this.filmDataSet.DataSetName = "filmDataSet";
            this.filmDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // salleDeCinemaBindingSource
            // 
            this.salleDeCinemaBindingSource.DataMember = "SalleDeCinema";
            this.salleDeCinemaBindingSource.DataSource = this.filmDataSet;
            // 
            // salleDeCinemaTableAdapter
            // 
            this.salleDeCinemaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.FilmTableAdapter = null;
            this.tableAdapterManager.ProgrammeTableAdapter = null;
            this.tableAdapterManager.RealisateurTableAdapter = null;
            this.tableAdapterManager.ReservationTableAdapter = null;
            this.tableAdapterManager.SalleDeCinemaTableAdapter = this.salleDeCinemaTableAdapter;
            this.tableAdapterManager.TypeDeSalleTableAdapter = this.typeDeSalleTableAdapter;
            this.tableAdapterManager.UpdateOrder = film.filmDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // typeDeSalleTableAdapter
            // 
            this.typeDeSalleTableAdapter.ClearBeforeFill = true;
            // 
            // salleDeCinemaBindingNavigator
            // 
            this.salleDeCinemaBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.salleDeCinemaBindingNavigator.BindingSource = this.salleDeCinemaBindingSource;
            this.salleDeCinemaBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.salleDeCinemaBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.salleDeCinemaBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.salleDeCinemaBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.salleDeCinemaBindingNavigatorSaveItem});
            this.salleDeCinemaBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.salleDeCinemaBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.salleDeCinemaBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.salleDeCinemaBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.salleDeCinemaBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.salleDeCinemaBindingNavigator.Name = "salleDeCinemaBindingNavigator";
            this.salleDeCinemaBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.salleDeCinemaBindingNavigator.Size = new System.Drawing.Size(800, 27);
            this.salleDeCinemaBindingNavigator.TabIndex = 0;
            this.salleDeCinemaBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorAddNewItem.Text = "Ajouter nouveau";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(48, 24);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Nombre total d\'éléments";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorDeleteItem.Text = "Supprimer";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Placer en premier";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Déplacer vers le haut";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Position actuelle";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Déplacer vers le bas";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Placer en dernier";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // salleDeCinemaBindingNavigatorSaveItem
            // 
            this.salleDeCinemaBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.salleDeCinemaBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("salleDeCinemaBindingNavigatorSaveItem.Image")));
            this.salleDeCinemaBindingNavigatorSaveItem.Name = "salleDeCinemaBindingNavigatorSaveItem";
            this.salleDeCinemaBindingNavigatorSaveItem.Size = new System.Drawing.Size(29, 24);
            this.salleDeCinemaBindingNavigatorSaveItem.Text = "Enregistrer les données";
            this.salleDeCinemaBindingNavigatorSaveItem.Click += new System.EventHandler(this.salleDeCinemaBindingNavigatorSaveItem_Click);
            // 
            // salleDeCinemaDataGridView
            // 
            this.salleDeCinemaDataGridView.AutoGenerateColumns = false;
            this.salleDeCinemaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.salleDeCinemaDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.salleDeCinemaDataGridView.DataSource = this.salleDeCinemaBindingSource;
            this.salleDeCinemaDataGridView.Location = new System.Drawing.Point(12, 277);
            this.salleDeCinemaDataGridView.Name = "salleDeCinemaDataGridView";
            this.salleDeCinemaDataGridView.RowHeadersWidth = 51;
            this.salleDeCinemaDataGridView.RowTemplate.Height = 24;
            this.salleDeCinemaDataGridView.Size = new System.Drawing.Size(553, 240);
            this.salleDeCinemaDataGridView.TabIndex = 1;
            this.salleDeCinemaDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.salleDeCinemaDataGridView_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn1.HeaderText = "id";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "nom";
            this.dataGridViewTextBoxColumn2.HeaderText = "nom";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "adresse";
            this.dataGridViewTextBoxColumn3.HeaderText = "adresse";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "idType";
            this.dataGridViewTextBoxColumn4.HeaderText = "idType";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // idTextBox
            // 
            this.idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.salleDeCinemaBindingSource, "id", true));
            this.idTextBox.Location = new System.Drawing.Point(90, 113);
            this.idTextBox.Name = "idTextBox";
            this.idTextBox.Size = new System.Drawing.Size(100, 22);
            this.idTextBox.TabIndex = 3;
            this.idTextBox.TextChanged += new System.EventHandler(this.idTextBox_TextChanged);
            // 
            // nomTextBox
            // 
            this.nomTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.salleDeCinemaBindingSource, "nom", true));
            this.nomTextBox.Location = new System.Drawing.Point(90, 141);
            this.nomTextBox.Name = "nomTextBox";
            this.nomTextBox.Size = new System.Drawing.Size(100, 22);
            this.nomTextBox.TabIndex = 5;
            this.nomTextBox.TextChanged += new System.EventHandler(this.nomTextBox_TextChanged);
            // 
            // adresseTextBox
            // 
            this.adresseTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.salleDeCinemaBindingSource, "adresse", true));
            this.adresseTextBox.Location = new System.Drawing.Point(90, 169);
            this.adresseTextBox.Name = "adresseTextBox";
            this.adresseTextBox.Size = new System.Drawing.Size(100, 22);
            this.adresseTextBox.TabIndex = 7;
            this.adresseTextBox.TextChanged += new System.EventHandler(this.adresseTextBox_TextChanged);
            // 
            // ajouter
            // 
            this.ajouter.Location = new System.Drawing.Point(333, 113);
            this.ajouter.Name = "ajouter";
            this.ajouter.Size = new System.Drawing.Size(75, 23);
            this.ajouter.TabIndex = 10;
            this.ajouter.Text = "ajouter";
            this.ajouter.UseVisualStyleBackColor = true;
            this.ajouter.Click += new System.EventHandler(this.ajouter_Click);
            // 
            // modifier
            // 
            this.modifier.Location = new System.Drawing.Point(333, 144);
            this.modifier.Name = "modifier";
            this.modifier.Size = new System.Drawing.Size(75, 23);
            this.modifier.TabIndex = 11;
            this.modifier.Text = "modifier";
            this.modifier.UseVisualStyleBackColor = true;
            this.modifier.Click += new System.EventHandler(this.modifier_Click);
            // 
            // supprimer
            // 
            this.supprimer.Location = new System.Drawing.Point(333, 174);
            this.supprimer.Name = "supprimer";
            this.supprimer.Size = new System.Drawing.Size(75, 23);
            this.supprimer.TabIndex = 12;
            this.supprimer.Text = "supprimer";
            this.supprimer.UseVisualStyleBackColor = true;
            this.supprimer.Click += new System.EventHandler(this.supprimer_Click);
            // 
            // nouveau
            // 
            this.nouveau.Location = new System.Drawing.Point(333, 204);
            this.nouveau.Name = "nouveau";
            this.nouveau.Size = new System.Drawing.Size(75, 23);
            this.nouveau.TabIndex = 13;
            this.nouveau.Text = "nouveau";
            this.nouveau.UseVisualStyleBackColor = true;
            this.nouveau.Click += new System.EventHandler(this.button4_Click);
            // 
            // typeDeSalleBindingSource
            // 
            this.typeDeSalleBindingSource.DataMember = "TypeDeSalle";
            this.typeDeSalleBindingSource.DataSource = this.filmDataSet;
            // 
            // typeDeSalleBindingSource1
            // 
            this.typeDeSalleBindingSource1.DataMember = "TypeDeSalle";
            this.typeDeSalleBindingSource1.DataSource = this.filmDataSet;
            // 
            // typeDeSalleComboBox
            // 
            this.typeDeSalleComboBox.DataSource = this.typeDeSalleBindingSource1;
            this.typeDeSalleComboBox.DisplayMember = "type";
            this.typeDeSalleComboBox.FormattingEnabled = true;
            this.typeDeSalleComboBox.Location = new System.Drawing.Point(90, 217);
            this.typeDeSalleComboBox.Name = "typeDeSalleComboBox";
            this.typeDeSalleComboBox.Size = new System.Drawing.Size(190, 24);
            this.typeDeSalleComboBox.TabIndex = 14;
            this.typeDeSalleComboBox.ValueMember = "id";
            this.typeDeSalleComboBox.SelectedIndexChanged += new System.EventHandler(this.typeDeSalleComboBox_SelectedIndexChanged);
            // 
            // retour
            // 
            this.retour.Location = new System.Drawing.Point(27, 45);
            this.retour.Name = "retour";
            this.retour.Size = new System.Drawing.Size(40, 28);
            this.retour.TabIndex = 15;
            this.retour.Text = "<--";
            this.retour.UseVisualStyleBackColor = true;
            this.retour.Click += new System.EventHandler(this.retour_Click);
            // 
            // FormSalleCinema
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 545);
            this.Controls.Add(this.retour);
            this.Controls.Add(this.typeDeSalleComboBox);
            this.Controls.Add(typeLabel);
            this.Controls.Add(this.nouveau);
            this.Controls.Add(this.supprimer);
            this.Controls.Add(this.modifier);
            this.Controls.Add(this.ajouter);
            this.Controls.Add(idLabel);
            this.Controls.Add(this.idTextBox);
            this.Controls.Add(nomLabel);
            this.Controls.Add(this.nomTextBox);
            this.Controls.Add(adresseLabel);
            this.Controls.Add(this.adresseTextBox);
            this.Controls.Add(this.salleDeCinemaDataGridView);
            this.Controls.Add(this.salleDeCinemaBindingNavigator);
            this.Name = "FormSalleCinema";
            this.Text = "FormSalleCinema";
            this.Load += new System.EventHandler(this.FormSalleCinema_Load);
            ((System.ComponentModel.ISupportInitialize)(this.filmDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salleDeCinemaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salleDeCinemaBindingNavigator)).EndInit();
            this.salleDeCinemaBindingNavigator.ResumeLayout(false);
            this.salleDeCinemaBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.salleDeCinemaDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeDeSalleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeDeSalleBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private filmDataSet filmDataSet;
        private System.Windows.Forms.BindingSource salleDeCinemaBindingSource;
        private filmDataSetTableAdapters.SalleDeCinemaTableAdapter salleDeCinemaTableAdapter;
        private filmDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator salleDeCinemaBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton salleDeCinemaBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView salleDeCinemaDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.TextBox idTextBox;
        private System.Windows.Forms.TextBox nomTextBox;
        private System.Windows.Forms.TextBox adresseTextBox;
        private System.Windows.Forms.Button ajouter;
        private System.Windows.Forms.Button modifier;
        private System.Windows.Forms.Button supprimer;
        private System.Windows.Forms.Button nouveau;
        private filmDataSetTableAdapters.TypeDeSalleTableAdapter typeDeSalleTableAdapter;
        private System.Windows.Forms.BindingSource typeDeSalleBindingSource;
        private System.Windows.Forms.BindingSource typeDeSalleBindingSource1;
        private System.Windows.Forms.ComboBox typeDeSalleComboBox;
        private System.Windows.Forms.Button retour;
    }
}